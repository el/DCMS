# ************************************************************
# Sequel Pro SQL dump
# Version 4135
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: veprom.com (MySQL 5.5.37-0ubuntu0.12.04.1)
# Database: zadmin_solar
# Generation Time: 2014-04-28 14:45:33 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table apps
# ------------------------------------------------------------

DROP TABLE IF EXISTS `apps`;

CREATE TABLE `apps` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `language` tinyint(4) NOT NULL DEFAULT '0',
  `parts` varchar(128) NOT NULL DEFAULT '',
  `sort` int(11) NOT NULL DEFAULT '0',
  `userlimit` int(11) NOT NULL DEFAULT '0',
  `google` tinyint(4) NOT NULL DEFAULT '0',
  `url` varchar(32) DEFAULT NULL,
  `iname` varchar(128) NOT NULL DEFAULT '',
  `iayarlar` text NOT NULL,
  `imount` varchar(256) NOT NULL,
  `iport` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `apps` WRITE;
/*!40000 ALTER TABLE `apps` DISABLE KEYS */;

INSERT INTO `apps` (`id`, `cid`, `language`, `parts`, `sort`, `userlimit`, `google`, `url`, `iname`, `iayarlar`, `imount`, `iport`)
VALUES
	(1,1,0,'',0,100,0,'cookshop','Cookshop','[1]','cookshop',6600);

/*!40000 ALTER TABLE `apps` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table bills
# ------------------------------------------------------------

DROP TABLE IF EXISTS `bills`;

CREATE TABLE `bills` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `firm` int(11) DEFAULT NULL,
  `date` varchar(32) DEFAULT NULL,
  `structure` text,
  `total` int(11) DEFAULT NULL,
  `app` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table cache
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cache`;

CREATE TABLE `cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(128) NOT NULL DEFAULT '',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `language` tinyint(4) NOT NULL DEFAULT '0',
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `app` int(11) DEFAULT NULL,
  `section` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `comment` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;

INSERT INTO `comments` (`id`, `app`, `section`, `cid`, `user`, `timestamp`, `comment`)
VALUES
	(1,0,26222812,1,1,'2013-11-18 18:01:14','Deneme Yorumu'),
	(3,0,26222812,1,1,'2013-11-18 18:05:27','İkinci Yorum'),
	(5,1,12642868,3,1,'2013-11-19 08:44:48','Deneme Yorumu'),
	(6,1,86182612,7,1,'2013-12-02 15:11:01','Çok güzel şube'),
	(7,1,22142116,1,1,'2014-01-27 00:07:47','heyyooo'),
	(8,1,22142116,1,1,'2014-01-28 18:47:03','hayda bree'),
	(9,1,46828841,42,1,'2014-01-29 23:54:01','Bu görev bitmeeez'),
	(10,1,46828841,1,1,'2014-02-07 12:51:42','Deneme'),
	(11,1,62466281,1,1,'2014-03-25 18:22:33','İngilizcesi eklenecek');

/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table flows
# ------------------------------------------------------------

DROP TABLE IF EXISTS `flows`;

CREATE TABLE `flows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `app` int(11) NOT NULL DEFAULT '0',
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1',
  `structure` text,
  `sort` int(11) NOT NULL DEFAULT '0',
  `name` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `flows` WRITE;
/*!40000 ALTER TABLE `flows` DISABLE KEYS */;

INSERT INTO `flows` (`id`, `app`, `start`, `end`, `flag`, `structure`, `sort`, `name`)
VALUES
	(1,1,NULL,NULL,1,NULL,0,'Deneme');

/*!40000 ALTER TABLE `flows` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table flows_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `flows_data`;

CREATE TABLE `flows_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flow_step` int(11) DEFAULT NULL,
  `status` enum('Waiting','Done') DEFAULT NULL,
  `data` text,
  `type` enum('Approve','Data','Comment') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table flows_structure
# ------------------------------------------------------------

DROP TABLE IF EXISTS `flows_structure`;

CREATE TABLE `flows_structure` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `flow_id` int(11) DEFAULT NULL,
  `step` tinyint(4) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `users` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table forms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `forms`;

CREATE TABLE `forms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `app` int(11) DEFAULT NULL,
  `flag` int(11) NOT NULL DEFAULT '3',
  `sort` int(11) NOT NULL DEFAULT '-1',
  `name` varchar(128) NOT NULL DEFAULT '',
  `structure` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table forms_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `forms_content`;

CREATE TABLE `forms_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `did` int(11) DEFAULT NULL,
  `iid` varchar(32) DEFAULT NULL,
  `value` varchar(512) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `text` text,
  `type` enum('value','number','text') NOT NULL DEFAULT 'value',
  PRIMARY KEY (`id`),
  KEY `data` (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table forms_data
# ------------------------------------------------------------

DROP TABLE IF EXISTS `forms_data`;

CREATE TABLE `forms_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `flag` enum('Sent','Completed','Waiting') NOT NULL DEFAULT 'Completed',
  `score` tinyint(4) DEFAULT NULL,
  `fdate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table forms_value
# ------------------------------------------------------------

DROP VIEW IF EXISTS `forms_value`;

CREATE TABLE `forms_value` (
   `id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
   `iid` VARCHAR(32) NULL DEFAULT NULL,
   `did` INT(11) NULL DEFAULT NULL,
   `type` VARCHAR(6) NOT NULL DEFAULT '',
   `val` TEXT NULL DEFAULT NULL
) ENGINE=MyISAM;



# Dump of table groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(64) NOT NULL DEFAULT '',
  `type` tinyint(4) NOT NULL,
  `app` smallint(6) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `up` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;

INSERT INTO `groups` (`gid`, `group_name`, `type`, `app`, `sort`, `up`)
VALUES
	(1,'Genel Admin',0,1,0,0),
	(2,'Yönetici',1,1,1,0),
	(3,'İzin Grubu',1,1,2,2);

/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table logs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(64) NOT NULL DEFAULT '',
  `ip` varchar(64) NOT NULL DEFAULT '',
  `type` varchar(128) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(128) NOT NULL DEFAULT '',
  `exception` text NOT NULL,
  `request` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table messages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sender` int(11) NOT NULL,
  `reciever` int(11) NOT NULL,
  `type` enum('App','User','Group') NOT NULL DEFAULT 'User',
  `status` enum('Read','Unread') NOT NULL DEFAULT 'Unread',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `message` text,
  `attachments` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table notifications
# ------------------------------------------------------------

DROP TABLE IF EXISTS `notifications`;

CREATE TABLE `notifications` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `notification` varchar(128) NOT NULL DEFAULT '',
  `status` enum('Read','Unread','Sent') NOT NULL DEFAULT 'Unread',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `type` enum('User','Group','System') NOT NULL DEFAULT 'User',
  `section` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `perm` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table repeat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `repeat`;

CREATE TABLE `repeat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `every` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `weekday` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table reports
# ------------------------------------------------------------

DROP TABLE IF EXISTS `reports`;

CREATE TABLE `reports` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `app` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `structure` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table routes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `routes`;

CREATE TABLE `routes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `language` int(11) DEFAULT NULL,
  `controller` varchar(32) DEFAULT NULL,
  `action` varchar(32) DEFAULT NULL,
  `route` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ROUTER` (`language`,`controller`,`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table settings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `db` varchar(128) COLLATE utf8_turkish_ci NOT NULL,
  `language` tinyint(4) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '-1',
  `cdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `type` tinyint(4) NOT NULL,
  `value0` varchar(256) COLLATE utf8_turkish_ci NOT NULL,
  `value1` text COLLATE utf8_turkish_ci NOT NULL,
  `value2` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;



# Dump of table tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tokens`;

CREATE TABLE `tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `type` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `token` varchar(1024) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `TOKEN` (`user`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('Active','Passive','Waiting','Mobile') NOT NULL DEFAULT 'Active',
  `name` varchar(64) NOT NULL DEFAULT '',
  `surname` varchar(64) NOT NULL DEFAULT '',
  `group_id` int(11) NOT NULL,
  `email` varchar(128) NOT NULL DEFAULT '',
  `phone` varchar(32) NOT NULL DEFAULT '',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `language` tinyint(4) NOT NULL DEFAULT '0',
  `prequest` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `status`, `name`, `surname`, `group_id`, `email`, `phone`, `date`, `username`, `password`, `language`, `prequest`)
VALUES
	(1,'Active','Eliz','KILIÇ',1,'elizkilic@veritronik.com.tr','05069241310','2012-03-22 12:33:29','elizkilic','6364d3f0f495b6ab9dcf8d3b5c6e0b01',0,0),
	(2,'Active','Eliz','KILIÇ',0,'elizkilic@gmail.com','','2012-07-16 06:36:52','root','cfcd208495d565ef66e7dff9f98764da',0,0),
	(3,'Active','Deneme','deneme',3,'Deneme@deneme.com','','2013-10-23 15:32:34','deneme','c9f0f895fb98ab9159f51fd0297e236d',0,0),
	(4,'Active','Test','Test',2,'test@test','','2013-10-23 15:42:51','test','ed3d2c21991e3bef5e069713af9fa6ca',0,0);

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;




# Replace placeholder table for forms_value with correct view syntax
# ------------------------------------------------------------

DROP TABLE `forms_value`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `forms_value`
AS SELECT
   `forms_content`.`id` AS `id`,
   `forms_content`.`iid` AS `iid`,
   `forms_content`.`did` AS `did`,
   `forms_content`.`type` AS `type`,
   `forms_content`.`value` AS `val`
FROM `forms_content` where (`forms_content`.`type` = 'value') union all select `forms_content`.`id` AS `id`,`forms_content`.`iid` AS `iid`,`forms_content`.`did` AS `did`,`forms_content`.`type` AS `type`,`forms_content`.`text` AS `val` from `forms_content` where (`forms_content`.`type` = 'text') union all select `forms_content`.`id` AS `id`,`forms_content`.`iid` AS `iid`,`forms_content`.`did` AS `did`,`forms_content`.`type` AS `type`,`forms_content`.`number` AS `val` from `forms_content` where (`forms_content`.`type` = 'number') order by `id`;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
